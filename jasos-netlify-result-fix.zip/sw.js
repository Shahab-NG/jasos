
const cacheName="jasos-3bcf179c14110bd0"
const files=["/","/app.webmanifest","/icon.svg","/assets/index-Bzzj8ve-.css","/assets/index-CZAmOxAg.js","/assets/vazirmatn-arabic-wght-normal-Cafbb7Zc.woff2","/assets/vazirmatn-latin-ext-wght-normal-tDTa1Fj6.woff2","/assets/vazirmatn-latin-wght-normal-BFexNX-K.woff2"]
self.addEventListener('install',event=>event.waitUntil(caches.open(cacheName).then(cache=>cache.addAll(files))))
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('jasos-')&&key!==cacheName).map(key=>caches.delete(key))))))
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url)
  if(event.request.method!=='GET'||url.origin!==location.origin)return
  if(event.request.mode==='navigate'){
    event.respondWith(fetch(event.request).catch(()=>caches.open(cacheName).then(cache=>cache.match('/'))))
  }else if(files.includes(url.pathname)){
    event.respondWith(caches.open(cacheName).then(cache=>cache.match(url.pathname)).then(hit=>hit||fetch(event.request)))
  }
})
